import UIKit
import SocketIO
import ObjectMapper
import SwiftyJSON

//MARK:- Socket Connection Manager Protocol
protocol SocketConnectionDelegate: class {
    func onSocketConnected()
    func onSocketDisconnected()
    func onReceivedMessage(messageObj: ChatMessage)
}
/**
 DayPlay : SocketConnectionManager
 
 This Class manages the socket operations for ChatViewController
 
 - Author:
 Danish Khan
 
 - Copyright:
 Zapbuild Technologies Pvt Ltd
 
 - Date:
 10/02/2020
 
 - Version:
 1.4
 */
class SocketConnectionManager{
    
    static let shared:SocketConnectionManager = SocketConnectionManager()
    var manager: SocketManager!
    var socket: SocketIOClient!
    private var appDelegate:UIApplicationDelegate! = nil
    weak var socketDelegate : SocketConnectionDelegate?
    
    private init() {
        self.appDelegate = UIApplication.shared.delegate
    }
    
    func connectSocket(){
        let user = CommonUtilities.getUserFromUserDefaults()
        
        manager = SocketManager(socketURL: URL(string: Constants.SocketDetail.new)!, config: [.log(true), .connectParams(["online" : user!.id!])])
        socket = manager.defaultSocket
        
        socket.on(clientEvent: .connect) {data, ack in
            self.socketDelegate?.onSocketConnected()
            Logger.log("socket connected")
        }
        
        socket.on(clientEvent: .disconnect) { (data, ack) in
            self.socketDelegate?.onSocketDisconnected()
            Logger.log("socket disconnect")
        }
        
        socket.on("message_added") {data, ack in
            if let dataStringJson = data[0] as? [String:Any] {
                if let dict = dataStringJson["message"] as? [String:Any] {
                    let messageObject = Mapper<ChatMessage>().map(JSON: dict)
                    self.socketDelegate?.onReceivedMessage(messageObj: messageObject!)
                }
            }
        }
        socket.connect()
    }
    
    func disconnectSocket(){
        self.socketDelegate?.onSocketDisconnected()
        socket.disconnect()
    }
    
    func reConnectSocket() {
        if !socket.status.active{
            connectSocket()
        }
    }
}


